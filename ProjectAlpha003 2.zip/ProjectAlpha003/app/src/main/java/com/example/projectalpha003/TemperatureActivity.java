package com.example.projectalpha003;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class TemperatureActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperture);

        ImageView image =(ImageView) findViewById(R.id.imageTemperature);
        image.setX(10);
        image.setY(-500);


        Button btn = (Button) findViewById(R.id.ShowDetailBtn);
        btn.setX(0);
        btn.setY(750);
    }


    public void JumpToSecond (View view)
    {

        System.out.println("jump");
        Intent intent = new Intent(TemperatureActivity.this, SecondActivity.class);
        startActivity(intent);

    }
}
